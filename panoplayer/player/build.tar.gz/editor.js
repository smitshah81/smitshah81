/* Panolence Editor Extension
*  Add/Edit/Delete Hotspot(Infospot)
*  @author  Smit Shah 
*  Email : Smitshah81@gmail.com
*/

window.PanoEditor = {};
var _editdata = new Array();
/* PanoEditor : get/set Data of hotspot
*
*/
( function () {
 PanoEditor = function(hotspotdata,fields){
	var _hotspotdata = hotspotdata;
	var _fielddata = fields;
	var enableeditor = 0;
	var hotspotid;
	var EDITOR_DEBUG = false;
//Preloaded hotspot data Depricated
	for (var field in _hotspotdata) {
		_editdata[object['hotspotid']][field] = object[field];


	}
	PanoEditor.Form(_fielddata);
	this.setData  = function(property,value)
	{
		_editdata[this.hotspotid][property] = value;
		
	}
	this.saveHotspot  = function()
	{
		
		var name=document.getElementById("name").value;
		var type=document.getElementById("type").value;
		if(type!="")
		{
			this.setData("type",type);
			var typevalue=document.getElementById("gettypevalue-"+type).value;
			this.setData("typevalue",typevalue);
		}
		var ordering=document.getElementById("ordering").value;
		this.setData("name",name);
		this.setData("ordering",ordering);

		//this.updateHotspotData();	
		
	}
	this.getData  = function(hotspotid)
	{

		
		if(hotspotid=="")
		{
			return _editdata[this.hotspotid];
		}
		else
		{
			return _editdata[hotspotid];
		}
		
	}
	this.setId = function(id){
		this.hotspotid = id;
	};
	this.updateHotspotData = function(hotspotInstence){
		

		var instencetoupdate;
		
			if(typeof hotspotInstence =="undefined") //not working @todo:
			{
				instencetoupdate=_editdata[this.hotspotid].hotspotInstence;
			}
			else
			{
				instencetoupdate =hotspotInstence;
			}
			
			var imagetype= _editdata[this.hotspotid].type;
			var iid= infospot+(Object.keys(_editdata).length + 1);
			console.log(imagetype);
			if(imagetype =="text")
			{
				imagetype="Info";
			}
			else if(imagetype=="screen")
			{
				imagetype="Arrow";
			}

			var  iid = new PANOLENS.Infospot( 350, PANOLENS.DataImage[imagetype]);
	       iid.position.set( _editdata[this.hotspotid].position.x,  _editdata[this.hotspotid].position.y,  _editdata[this.hotspotid].position.z );
	       iid.hotspotid=this.hotspotid;
	       if(imagetype =="audio" || imagetype =="video")
	       {
	       		document.getElementById("desc-container").innerHTML="";
	       		if(imagetype =="audio")
	       		{
	       			document.getElementById("desc-container").innerHTML=this.getAudioHtml(_editdata[this.hotspotid].typevalue);
	       		}
	       		else
	       		{
	       			document.getElementById("desc-container").innerHTML=this.getVideoHtml(_editdata[this.hotspotid].typevalue);
	       		}
	       		iid.addHoverElement	( document.getElementById("desc-container") );
	       }
	       else if(imagetype =="image")
	       {
	       		document.getElementById("desc-container").innerHTML=this.getImageHtml(_editdata[this.hotspotid].typevalue);
	       }
	       else if(imagetype =="Info")
	       {
	       		 iid.addHoverText	( _editdata[this.hotspotid].name);
	       }
	       else if(imagetype =="Arrow")
	       {
	       		//panorama.link(2);
	       }
	      
	       _editdata[this.hotspotid]['hotspotInstence'] = iid
			iid.visible=true;
		   panorama.add( iid );
		   hotspotInstence.dispose();	

	};
	this.getVideoHtml = function(videourl){
		var video ='<div class="leanback-player-video">';
       	video +='<video  preload="metadata" controls >';//poster="./folder/poster.jpg"
		video +='<source src="'+videourl+'" type=\'video/mp4; codecs="avc1.42E01E, mp4a.40.2"\'/>';
	    video+='</video>';
	    video+='</div>';
	    video+='<div class="title">';
	    video+=_editdata[this.hotspotid].name;
	    video+='</div>';
	    video+='<div class="text">';
	    video+='</div>';
		return	video;
	};
	this.getAudioHtml = function(audiourl)
	{
		var audio ='<div class="leanback-player-audio">';
      	audio +='<audio  preload="metadata" controls >';//poster="./folder/poster.jpg"
		audio +='<source src="'+audiourl+'" type=\'audio/mpeg; codecs="vorbis"\'/>';
    	audio+='</audio>';
    	audio+='<div class="title">';
    	audio+=_editdata[this.hotspotid].name;
    	audio+='</div>';
    	audio+='<div class="text">';
    	audio+='</div>';
    	audio+='</div>';
		return	audio;
	};
	this.getImageHtml = function(imageurl)
	{
	
      
    	var image ='<img src="'+imageurl+'" class="image" />';
    	image+='<div class="title">';
    	image+=_editdata[this.hotspotid].name;
    	image+='</div>';
    	image+='<div class="text">';
    	image+='</div>';
    	image+='</div>';
		return	image;
	};
	this.setFormData = function()
	{

		var formData=this.getData(this.hotspotid);
		//
			for(var field in formData)
			{
				if(field=="type")
				{	
					document.getElementById(field).value=formData[field];
					document.getElementById(field)[document.getElementById(field).selectedIndex].selected=true;
					document.getElementById(field).onchange();
					
				}
				if(field=="typevalue")
				{	
					
					getTypeValue(formData['type']);
				}

				if(document.getElementById(field) !=null)
				{
					if(document.getElementById(field).type =="text")
					{
						document.getElementById(field).value=formData[field];
					}
					else if(document.getElementById(field).type =="textarea")
					{
						document.getElementById(field).text=formData[field];
					}
					else if(document.getElementById(field).type =="select")
					{
						
						document.getElementById(field)[document.getElementById(field).selectedIndex].value=formData[field];
						
					}
				}
			}
	};
	this.createNewHotspot = function(point)
	{
		var utility = new PanoEditor.Utils();
		this.hotspotid =  utility.generateId();

		var iid= infospot+(Object.keys(_editdata).length + 1);
		var  iid = new PANOLENS.Infospot( 350, PANOLENS.DataImage.Info);
       iid.position.set( -point.x.toFixed(2), point.y.toFixed(2), point.z.toFixed(2) );
       iid.hotspotid=this.hotspotid;
       iid.addHoverText	( "New Hotspot");

		//console.log(this.hotspotid);
		_editdata[this.hotspotid] = {
			name: "New Hotspot",
			ordering : Object.keys(_editdata).length + 1,
			position : {"x":-point.x.toFixed(2),"y":point.y.toFixed(2),"z":point.z.toFixed(2)},
			type:"",
			typevalue:"",
			hotspotInstence:iid
		};

		

       panorama.add( iid );
       this.setFormData();

	}
	this.saveData = function(url)
	{
		if(url!="")
		{
			var utility = new PanoEditor.Utils();
			var dataexport = new Array();
			for(var i in _editdata){ 	_editdata[i].hotspotInstence=""; 	 dataexport.push(_editdata[i]);}
				dataexport.push({image:"03.jpg"});
				data=JSON.stringify(dataexport);

			utility.exportHotspotData(data,url);
		}
	}

};
PanoEditor.Utils = function(){

	var d = new Date();
	var milliseconds ;
	this.generateId = function()
	{
		milliseconds= d.getMilliseconds();
		return "t"+parseInt((Math.random()*10000)+milliseconds);
	};
	this.exportHotspotData = function(data,url){
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", url, true);
		
	    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
	    xhttp.send(data);

	    xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) {
	      	
	      	//if(EDITOR_DEBUG==true){console.log(xhttp.responseText);return xhttp.responseText;}else{console.log(xhttp.responseText);return xhttp.responseText;}
	    }
	    
  		
	};
};
};
PanoEditor.Form = function(fields){
		this.fields = fields;

		 fieldgroup = document.createElement( 'div' );
		fieldgroup.style.width = '156px';
		fieldgroup.style.float = 'right';
		fieldgroup.style.bottom = "50px";
		fieldgroup.style.right = 0;
		fieldgroup.style.padding = "5px";
		fieldgroup.style.position = 'absolute';
		
		
		fieldgroup.style.transform = fieldgroup.style.webkitTransform = fieldgroup.style.msTransform = 'translateX(-30%)';
		fieldgroup.style.background = 'rgba( 0, 0, 0, 0.3 )';
		fieldgroup.style.transition = 'all 0.5s ease';
		fieldgroup.isHidden = false;
		fieldgroup.id="controlfieldgroup";
		fieldgroup.isHidden = !fieldgroup.isHidden;
			
		panorama.container.appendChild( fieldgroup );

		// Event listener
		PANOLENS.Widget.prototype.addEventListener( 'control-fieldgroup-toggle', fieldgroup.toggle );

		this.Elementgrp = fieldgroup;
		

	this.addFields = function (  ) {

		for (var i=0;i<this.fields.length;i++) {
			
			this.Elementgrp.appendChild( this.createField(this.fields[i]) );
		}
	};
	this.createField = function(singlefield){																																																															

		var fieldHTML;
		var attrHTML="";
		var field = singlefield;
		//console.log(field.type);
		if(field.type ==="text")
		{
			fieldHTML = document.createElement( 'input' );
			
		}
		else if(field.type=="select")
		{
			fieldHTML = document.createElement( 'SELECT' );
			
			for (var option in field.options) {
				
				
				var optione = document.createElement("option");
					optione.text = field.options[option];
					optione.value = option;
					fieldHTML.add(optione);
			
			}

		}
		else if(field.type=="textarea")
		{
			fieldHTML = document.createElement( 'textarea' );
		}
		else if(field.type=="checkbox")
		{
			fieldHTML = document.createElement( 'checkbox' );
		}
		else if(field.type=="button")
		{
			fieldHTML = document.createElement( 'BUTTON' );
			fieldHTML.innerHTML=field.attr.text;
		}
		else
		{
			console.log("Invalid Field Type :"+field.type);
		}
		for (var allattr in field.attr) {
				fieldHTML.setAttribute(allattr,field.attr[allattr]);
			
		}

		return fieldHTML;
};
		this.addFields();
		document.body.appendChild( this.Elementgrp );
		PANOLENS.Viewer.prototype.toggleEditor(0);
};
})(PanoEditor);

